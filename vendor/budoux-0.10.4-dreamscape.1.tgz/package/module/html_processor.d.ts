/**
 * @license
 * Copyright 2021 Google LLC
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { Parser } from './parser.js';
export declare const PARENT_CSS_STYLE = "word-break: keep-all; overflow-wrap: anywhere;";
/**
 * Applies wrapping styles to make linebreak controls work in children.
 * @param element A parent element to apply the styles.
 */
export declare const applyWrapStyle: (element: HTMLElement) => void;
/**
 * Represents a node in {@link Paragraph}.
 *
 * It wraps a {@link Text} or a {@link string}.
 *
 * A {@link string} provides the context for the parser, but it can't be split.
 */
declare class NodeOrText {
    nodeOrText: Text | string;
    chunks: string[];
    hasBreakOpportunityAfter: boolean;
    constructor(nodeOrText: Text | string);
    private static isString;
    get canSplit(): boolean;
    get text(): string | null;
    get length(): number;
    /**
     * Split the {@link Text} in the same way as the {@link chunks}.
     * Joining all {@link chunks} must be equal to {@link text}.
     */
    split(separator: string | Node): void;
}
export declare class NodeOrTextForTesting extends NodeOrText {
}
/**
 * Represents a "paragraph", broken by block boundaries or forced breaks.
 *
 * A CSS
 * {@link https://drafts.csswg.org/css2/#inline-formatting inline formatting context}
 * is usually a "paragraph", but it can be broken into multiple paragraphs by
 * forced breaks such as `<br>`.
 */
declare class Paragraph {
    element: HTMLElement | DocumentFragment;
    nodes: NodeOrText[];
    constructor(element: HTMLElement | DocumentFragment);
    isEmpty(): boolean;
    get text(): string;
    get lastNode(): NodeOrText | undefined;
    setHasBreakOpportunityAfter(): void;
    /**
     * @return Indices of forced break opportunities in the source.
     * They can be created by `<wbr>` tag or `&ZeroWidthSpace;`.
     */
    getForcedOpportunities(): number[];
    /**
     * @return Filtered {@param boundaries} by excluding
     * {@link getForcedOpportunities} if it's not empty.
     * Otherwise {@param boundaries}.
     */
    excludeForcedOpportunities(boundaries: number[]): number[];
}
export declare class ParagraphForTesting extends Paragraph {
}
/**
 * Options for {@link HTMLProcessor}.
 */
export interface HTMLProcessorOptions {
    /**
     * This class name is added to the containing block when the BudouX is applied.
     * The containing block should have following CSS properties to make it work.
     * `{ word-break: keep-all; overflow-wrap: anywhere; }`
     *
     * When falsy, an inline style is set instead.
     */
    className?: string;
    /**
     * The separator to insert at each semantics boundary.
     *
     * When it's a {@link Node}, a clone of the {@link Node} will be inserted.
     *
     * The default value is U+200B ZERO WIDTH SPACE.
     */
    separator?: string | Node;
}
/**
 * Adds HTML processing support to a BudouX {@link Parser}.
 */
export declare class HTMLProcessor {
    private parser_;
    /** See {@link HTMLProcessorOptions.className}. */
    className?: string;
    /** See {@link HTMLProcessorOptions.separator}. */
    separator: string | Node;
    /**
     * @param parser A BudouX {@link Parser} to compute semantic line breaks.
     */
    constructor(parser: Parser, options?: HTMLProcessorOptions);
    /**
     * Checks if the given element has a text node in its children.
     *
     * @param ele An element to be checked.
     * @return Whether the element has a child text node.
     */
    static hasChildTextNode(ele: HTMLElement | DocumentFragment): boolean;
    /**
     * Applies markups for semantic line breaks to the given HTML element or document fragment.
     *
     * It breaks descendant nodes into paragraphs,
     * and applies the BudouX to each paragraph.
     * @param element The input element or document fragment.
     */
    applyToElement(element: HTMLElement | DocumentFragment): void;
    /**
     * Find paragraphs from a given HTML element or document fragment.
     * @param element The root element or document fragment to find paragraphs.
     * @param parent The parent {@link Paragraph} if any.
     * @return A list of {@link Paragraph}s.
     */
    getBlocks(element: HTMLElement | DocumentFragment, parent?: Paragraph): IterableIterator<Paragraph>;
    /**
     * Apply the BudouX to the given {@link Paragraph}.
     * @param paragraph The {@link Paragraph} to apply.
     * @param shouldApplyBlockStyle Whether to apply block styles to the paragraph element.
     */
    applyToParagraph(paragraph: Paragraph, shouldApplyBlockStyle?: boolean): void;
    /**
     * Split {@link NodeOrText} at the specified boundaries.
     * @param nodes A list of {@link NodeOrText}.
     * @param boundaries A list of indices of the text to split at.
     */
    splitNodes(nodes: NodeOrText[], boundaries: number[]): void;
    /**
     * Applies the block style to the given element or document fragment.
     * @param element The element or document fragment to apply the block style.
     */
    applyBlockStyle(element: HTMLElement | DocumentFragment): void;
}
/**
 * BudouX {@link Parser} with HTML processing support.
 */
export declare class HTMLProcessingParser extends Parser {
    htmlProcessor: HTMLProcessor;
    constructor(model: {
        [key: string]: {
            [key: string]: number;
        };
    }, htmlProcessorOptions?: HTMLProcessorOptions);
    /**
     * Applies markups for semantic line breaks to the given HTML element or document fragment.
     * @param parentElement The input element or document fragment.
     */
    applyToElement(parentElement: HTMLElement | DocumentFragment): void;
    /**
     * Translates the given HTML string to another HTML string with markups
     * for semantic line breaks.
     *
     * When `wrap` is `true` (default), the output is wrapped in a `<span>` element
     * (if needed) and block styles (or class name) are applied to paragraph elements.
     * When `wrap` is `false`, the HTML string is segmented without wrapping in a
     * `<span>` or applying block styles.
     *
     * @param html An input html string.
     * @param wrap Whether to wrap the output in a `<span>` element (if needed) and
     * apply block styles. Defaults to true.
     * @return The translated HTML string.
     */
    translateHTMLString(html: string, wrap?: boolean): string;
}
export {};
